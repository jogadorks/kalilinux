const daftarvip = (prefix) => { 
	return `
	
 Para Criar Conta Vip Fale Com O Suporte Do Kali

 Preços 💸
1 semana 10 reais 💸
1 mes 25 reais💸
ou  Faça Sua Proposta!!

Suporte:
wa.me/+552788171482
  `
}
exports.daftarvip = daftarvip
